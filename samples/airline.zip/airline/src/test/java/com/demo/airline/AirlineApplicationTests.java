package com.demo.airline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
